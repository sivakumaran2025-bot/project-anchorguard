#!/usr/bin/env python3
"""
AnchorGuard - live telemetry collector (CI helper)
==================================================

Polls a RUNNING `telemetry_simulator.py serve` instance at a fixed rate and writes the
samples in the same JSON layout `telemetry_simulator.py generate` produces, so that
`profiler_engine.py` can evaluate it. Standard library only.

Shadow-target model (MOCK, for the hackathon demo)
--------------------------------------------------
With `--profile auto` (default) the simulated workload intensity is derived from the repo:
if `worker_thread_pool_size` in the runtime config exceeds `--thread-limit`, the shadow
target behaves like the "anomaly" profile; otherwise "normal". This closes the demo loop:
the auto-remediation patch lowers the thread pool, the next pipeline samples a clean target.
In a real deployment this script would be replaced by a collector reading real power /
perf-counter sensors from a staging host.

Exit codes: 0 ok, 2 collection/config error.
"""

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional


def resolve_profile(profile: str, config_path: str, thread_limit: int) -> Dict[str, Any]:
    if profile in ("normal", "anomaly"):
        return {"profile": profile, "reason": "explicit --profile %s" % profile}
    try:
        text = open(config_path, "r", encoding="utf-8").read()
    except OSError as exc:
        raise SystemExit("cannot read %s for --profile auto: %s" % (config_path, exc))
    m = re.search(r"^\s*worker_thread_pool_size\s*=\s*(\d+)\s*$", text, re.MULTILINE)
    if not m:
        raise SystemExit("worker_thread_pool_size not found in %s" % config_path)
    threads = int(m.group(1))
    chosen = "anomaly" if threads > thread_limit else "normal"
    return {"profile": chosen, "reason": "worker_thread_pool_size=%d %s %d -> simulated profile=%s"
            % (threads, ">" if threads > thread_limit else "<=", thread_limit, chosen),
            "worker_thread_pool_size": threads}


def wait_healthy(base: str, timeout_s: float) -> None:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(base + "/health", timeout=1.0) as r:
                if r.status == 200:
                    return
        except (urllib.error.URLError, OSError):
            time.sleep(0.25)
    raise SystemExit("simulator at %s not healthy after %.0fs" % (base, timeout_s))


def collect(base: str, profile: str, cores: int, duration: float, rate: float,
            max_error_rate: float) -> List[Dict[str, Any]]:
    url = "%s/metrics?profile=%s&cores=%d" % (base, profile, cores)
    period = 1.0 / rate
    total = int(duration * rate)
    samples: List[Dict[str, Any]] = []
    errors = 0
    start = time.perf_counter()
    for i in range(total):
        target = start + i * period
        delay = target - time.perf_counter()
        if delay > 0:
            time.sleep(delay)
        try:
            with urllib.request.urlopen(url, timeout=2.0) as r:
                samples.append(json.loads(r.read().decode("utf-8")))
        except (urllib.error.URLError, OSError, ValueError):
            errors += 1
    if total == 0 or errors / total > max_error_rate:
        raise SystemExit("collection failed: %d/%d requests errored" % (errors, total))
    return samples


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--url", default="http://127.0.0.1:8000")
    ap.add_argument("--profile", choices=("auto", "normal", "anomaly"), default="auto")
    ap.add_argument("--config", default="config/runtime_limits.conf")
    ap.add_argument("--thread-limit", type=int, default=8)
    ap.add_argument("--cores", type=int, default=8)
    ap.add_argument("--duration", type=float, default=30.0)
    ap.add_argument("--rate", type=float, default=50.0)
    ap.add_argument("--wait-healthy", type=float, default=15.0)
    ap.add_argument("--max-error-rate", type=float, default=0.05)
    ap.add_argument("--output", "-o", default="telemetry.json")
    args = ap.parse_args(argv)

    try:
        target = resolve_profile(args.profile, args.config, args.thread_limit)
        print("[collector] shadow target: %s" % target["reason"], flush=True)
        wait_healthy(args.url.rstrip("/"), args.wait_healthy)
        t0 = time.time()
        samples = collect(args.url.rstrip("/"), target["profile"], args.cores,
                          args.duration, args.rate, args.max_error_rate)
    except SystemExit as exc:
        print("[collector] ERROR: %s" % exc, file=sys.stderr)
        return 2
    doc = {"metadata": {"source": "live-poll", "url": args.url, "requested_profile": target["profile"],
                        "profile_reason": target["reason"], "cores": args.cores,
                        "duration_s": args.duration, "target_rate_hz": args.rate,
                        "sample_count": len(samples), "start_epoch": t0},
           "samples": samples}
    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, separators=(",", ":"))
    span = samples[-1]["t_offset_s"] - samples[0]["t_offset_s"] if len(samples) > 1 else 0
    print("[collector] %d samples, achieved %.1f Hz -> %s"
          % (len(samples), (len(samples) - 1) / span if span else 0, args.output), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())

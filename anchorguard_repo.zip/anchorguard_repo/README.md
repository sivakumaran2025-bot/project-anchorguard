# Project AnchorGuard

Hardware-aware DevSecOps compliance gating for GitLab. AnchorGuard watches the *physical* footprint of a
build (power draw, memory bandwidth, per-core CPU load) to catch stealth compute abuse such as
crypto-jacking, blocks deployment on FAIL, and uses a GitLab Duo agent/flow to open an isolated
remediation merge request automatically.

> Built for a GitLab hackathon. All telemetry is **synthetic** (no real malware or hardware needed).

## Components

| File | Purpose |
|---|---|
| `telemetry_simulator.py` | Mock target emitting normal or anomalous telemetry (`serve` HTTP / `generate` offline) |
| `profiler_engine.py` | Mathematical profiler: PASS/FAIL, remediation patch, signed compliance passport |
| `mcp_server.py` | MCP bridge exposing `get_build_telemetry(profile, cores)` to AI agents |
| `collect_telemetry.py`, `verify_passport.py` | CI helpers (live sampling, production gate) |
| `.gitlab-ci.yml` | MR pipeline: validate, shadow-eval, compliance-gate, deploy-production |
| `.gitlab/duo/` | Duo custom agent prompt, autonomous flow, MCP client config |

## Quick start (Python 3.8+, standard library only)

```bash
python telemetry_simulator.py generate --profile anomaly --duration 30 --rate 50 --seed 42 -o t.json
export ANCHORGUARD_SIGNING_KEY="choose-a-long-random-secret"
python profiler_engine.py t.json --out-dir out --build-id local   # exit 1 = FAIL, writes remediation_patch.diff
```

The MCP bridge additionally needs `pip install "mcp[cli]<2" httpx` (Python 3.10+).
See **DEPLOYMENT.md** for the GitLab pipeline, Duo agent/flow setup, and a 3-minute demo script.

## License
MIT. See `LICENSE`.

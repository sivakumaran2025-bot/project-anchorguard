#!/usr/bin/env python3
"""
Project AnchorGuard - MCP Telemetry Bridge
==========================================

Exposes the AnchorGuard hardware-telemetry simulator (`telemetry_simulator.py`)
to external AI agents (e.g. a GitLab Duo Agent) through the Model Context
Protocol over the stdio transport.

Architecture
------------

    AI agent  --(MCP / stdio)-->  mcp_server.py  --(HTTP GET /metrics)-->  telemetry_simulator.py serve

Prerequisites
-------------
    pip install "mcp[cli]<2" httpx        # Python 3.10+ (required by the mcp SDK)
    python telemetry_simulator.py serve   # must be running before the tool is called

Configuration (environment variables, all optional)
---------------------------------------------------
    ANCHORGUARD_SIM_URL      Base URL of the simulator   (default: http://127.0.0.1:8000)
    ANCHORGUARD_HTTP_TIMEOUT Request timeout in seconds  (default: 5.0)

Example MCP client configuration
--------------------------------
    {
      "mcpServers": {
        "anchorguard-telemetry": {
          "command": "python",
          "args": ["mcp_server.py"],
          "env": {"ANCHORGUARD_SIM_URL": "http://127.0.0.1:8000"}
        }
      }
    }

SDK version note: `mcp.server.fastmcp.FastMCP` is the mcp 1.x API (pin `mcp<2`). mcp 2.x
renamed it to `mcp.server.mcpserver.MCPServer`; the import block below falls back to it
automatically, so the script runs on either major version.

IMPORTANT: with the stdio transport, stdout is the protocol channel. Never
print() to stdout in this file; all diagnostics go to stderr via `logging`.
"""

import json
import logging
import os
import sys
from typing import Annotated, Literal

import httpx
from pydantic import Field

try:
    # mcp 1.x (the officially requested import path)
    from mcp.server.fastmcp import FastMCP
except ModuleNotFoundError:  # pragma: no cover - mcp 2.x renamed FastMCP to MCPServer
    from mcp.server.mcpserver import MCPServer as FastMCP

# --------------------------------------------------------------------------- #
# Configuration & logging (stderr only - stdout belongs to the MCP protocol)
# --------------------------------------------------------------------------- #
SIMULATOR_BASE_URL = os.environ.get("ANCHORGUARD_SIM_URL", "http://127.0.0.1:8000").rstrip("/")


def _read_timeout() -> float:
    try:
        value = float(os.environ.get("ANCHORGUARD_HTTP_TIMEOUT", "5.0"))
        return value if value > 0 else 5.0
    except ValueError:
        return 5.0


HTTP_TIMEOUT_S = _read_timeout()
VALID_PROFILES = ("normal", "anomaly")
MIN_CORES, MAX_CORES = 1, 256

logging.basicConfig(level=logging.INFO, stream=sys.stderr,
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
LOG = logging.getLogger("anchorguard.mcp")

# --------------------------------------------------------------------------- #
# Server
# --------------------------------------------------------------------------- #
mcp = FastMCP(
    "AnchorGuard-Telemetry-Bridge",
    instructions=(
        "Bridge to the AnchorGuard hardware-telemetry simulator. Use "
        "`get_build_telemetry` to sample synthetic runtime power, CPU and memory "
        "metrics of an application build, then analyse the packet for side-channel "
        "anomalies. A single sample is a point-in-time reading; call the tool "
        "repeatedly to build a time series."
    ),
)


def _offline_help(reason: str) -> str:
    """Actionable guidance returned to the agent when the simulator is unreachable."""
    return (
        f"ERROR: {reason}\n\n"
        "The AnchorGuard telemetry simulator is not reachable. Start it first, in a "
        "separate terminal, from the project directory:\n\n"
        "    python telemetry_simulator.py serve\n\n"
        f"It listens on 127.0.0.1:8000 by default. This bridge is currently configured "
        f"to call {SIMULATOR_BASE_URL} (override with the ANCHORGUARD_SIM_URL "
        "environment variable). Verify it with:\n\n"
        f"    curl {SIMULATOR_BASE_URL}/health\n\n"
        "Then retry this tool call."
    )


@mcp.tool()
async def get_build_telemetry(
    profile: Annotated[
        Literal["normal", "anomaly"],
        Field(description=(
            "Behavioural profile of the simulated build. 'normal' = stable ~150 W "
            "power draw with minor predictable fluctuation and noise. 'anomaly' = "
            "normal behaviour PLUS a subtle ~5 Hz cyclic burst in power draw and "
            "memory bandwidth and a correlated load bump on a subset of CPU cores, "
            "simulating an unauthorised background cryptographic / compute-theft "
            "workload."
        )),
    ],
    cores: Annotated[
        int,
        Field(ge=MIN_CORES, le=MAX_CORES,
              description="Number of CPU cores to report in cpu_cycle_distribution "
                          "(1-256). Defaults to 8."),
    ] = 8,
) -> str:
    """Fetch ONE runtime hardware-telemetry sample for a simulated application build.

    Use this tool to obtain physical side-channel metrics (power, CPU, memory) of an
    executing build so you can evaluate whether it behaves normally or shows signs of
    hidden compute activity. The data is synthetic and produced by the AnchorGuard
    simulator; no real hardware is measured.

    Returns a JSON object (as text) with these fields:
      - timestamp (float): wall-clock epoch time of the sample, in seconds.
      - t_offset_s (float): seconds elapsed since the simulator started.
      - profile (str): "normal" or "anomaly" - the profile that generated the sample.
      - cpu_cycle_distribution (list[float]): per-core load, each in 0.0-1.0; the list
        has `cores` entries.
      - power_draw_watts (float): instantaneous power draw; baseline is about 150 W.
      - memory_bandwidth_utilization (float): fraction of peak bandwidth, 0.0-1.0.

    Interpretation guidance:
      - A single sample is one point in time. The anomaly signature is a ~5 Hz periodic
        burst (roughly +3.5 W power, +0.08 memory utilisation, +0.12 load on about a
        quarter of the cores) that is only reliably distinguishable from noise across
        MANY samples. Tool calls are far too slow to resolve a 5 Hz cycle directly, so
        do not look for the oscillation itself. Instead call this tool repeatedly and
        compare the statistics of 'normal' vs 'anomaly' samples, e.g. mean and
        variance of power_draw_watts, mean memory_bandwidth_utilization, and which
        cores sit consistently higher.
      - Use t_offset_s to order samples in time.

    Error behaviour: if the simulator is offline, times out or rejects the request, the
    tool does NOT raise; it returns a plain-text message beginning with "ERROR:" that
    explains the problem and how to start the simulator
    (`python telemetry_simulator.py serve`).

    Examples:
      get_build_telemetry(profile="normal")
      get_build_telemetry(profile="anomaly", cores=16)
    """
    # Defence in depth: the schema already constrains these, but the function may
    # also be invoked directly (tests, other Python callers).
    if profile not in VALID_PROFILES:
        return f"ERROR: invalid profile {profile!r}. Use one of: {', '.join(VALID_PROFILES)}."
    if not isinstance(cores, int) or isinstance(cores, bool) or not MIN_CORES <= cores <= MAX_CORES:
        return f"ERROR: invalid cores {cores!r}. Provide an integer between {MIN_CORES} and {MAX_CORES}."

    url = f"{SIMULATOR_BASE_URL}/metrics"
    params = {"profile": profile, "cores": cores}

    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_S) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            packet = response.json()
    except httpx.ConnectError:
        LOG.warning("Simulator unreachable at %s", SIMULATOR_BASE_URL)
        return _offline_help("connection refused or host unreachable")
    except httpx.TimeoutException:
        LOG.warning("Simulator timed out after %.1fs", HTTP_TIMEOUT_S)
        return _offline_help(f"request timed out after {HTTP_TIMEOUT_S:g} seconds")
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:300]
        LOG.warning("Simulator returned HTTP %s: %s", exc.response.status_code, detail)
        return (f"ERROR: the simulator rejected the request with HTTP "
                f"{exc.response.status_code}: {detail}")
    except ValueError:
        # response.json() raises json.JSONDecodeError (a ValueError subclass)
        LOG.warning("Simulator returned a non-JSON body")
        return ("ERROR: the endpoint responded, but not with valid JSON. Confirm that "
                f"{SIMULATOR_BASE_URL} is the AnchorGuard telemetry simulator.")
    except httpx.HTTPError as exc:
        LOG.warning("Unexpected HTTP error: %r", exc)
        return _offline_help(f"unexpected network error ({type(exc).__name__})")

    return json.dumps(packet, indent=2)


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    LOG.info("Starting AnchorGuard-Telemetry-Bridge (stdio); simulator at %s", SIMULATOR_BASE_URL)
    mcp.run(transport="stdio")

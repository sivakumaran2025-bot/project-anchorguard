# AGENTS.md - AnchorGuard

Context for GitLab Duo flows and agents working in this repository.

## What this repo is
Hardware-aware compliance gating. A mock target emits power / memory-bandwidth / per-core CPU
telemetry; a mathematical profiler decides PASS or FAIL; FAIL blocks deployment.

## Files
- `telemetry_simulator.py` - mock target (`serve` HTTP / `generate` offline). Standard library only.
- `collect_telemetry.py` - polls the running simulator into a dataset (CI helper).
- `profiler_engine.py` - the verdict engine. Exit codes: 0 PASS, 1 FAIL, 2 error.
- `verify_passport.py` - production gate: verifies the signed compliance passport.
- `mcp_server.py` - MCP bridge exposing `get_build_telemetry(profile, cores)`.
- `config/runtime_limits.conf` - the ONLY file automated remediation may change.

## Rules for automated changes
- Remediation edits `config/runtime_limits.conf` only, and only lowers limits.
- Never change detection thresholds, profiler/simulator/verifier code, or `.gitlab-ci.yml` to
  make a build pass. Never create or edit `compliance_passport.json`.
- Remediation goes on branch `anchorguard/remediate-mr<IID>` and targets the offending MR's source
  branch. One attempt per MR; a human reviews and merges.

## Useful commands
- `python telemetry_simulator.py serve` then `curl 'http://127.0.0.1:8000/metrics?profile=anomaly'`
- `python telemetry_simulator.py generate --profile anomaly --duration 30 --rate 50 -o t.json`
- `python profiler_engine.py t.json --out-dir out --build-id local`

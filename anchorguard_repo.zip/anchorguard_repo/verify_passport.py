#!/usr/bin/env python3
"""
AnchorGuard - production gate verifier (CI helper)
==================================================

Verifies a Cryptographic Compliance Passport before anything is allowed to ship:
  1. HMAC-SHA256 signature is valid for ANCHORGUARD_SIGNING_KEY and the passport is unexpired
  2. verdict == PASS and production_gate == APPROVED
  3. (optional) the passport's telemetry hash matches the telemetry file actually evaluated
  4. (optional) the profiler report agrees (status PASS, same dataset hash)

Exit codes: 0 = verified, 1 = REJECTED (block deployment), 2 = usage/IO error.
"""
import argparse
import hashlib
import json
import os
import sys

from profiler_engine import verify_passport


def _load(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _telemetry_hash(path):
    data = _load(path)
    samples = data["samples"] if isinstance(data, dict) else data
    return hashlib.sha256(json.dumps(samples, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser(description="Verify an AnchorGuard compliance passport.")
    ap.add_argument("--passport", required=True)
    ap.add_argument("--telemetry")
    ap.add_argument("--report")
    args = ap.parse_args(argv)
    key = os.environ.get("ANCHORGUARD_SIGNING_KEY")
    if not key:
        print("REJECTED: ANCHORGUARD_SIGNING_KEY is not set", file=sys.stderr)
        return 2
    try:
        passport = _load(args.passport)
    except (OSError, ValueError) as exc:
        print("REJECTED: cannot read passport: %s" % exc)
        return 1                      # no passport == no deployment

    ok, reason = verify_passport(passport, key.encode("utf-8"))
    problems = [] if ok else [reason]
    if passport.get("verdict") != "PASS" or passport.get("production_gate") != "APPROVED":
        problems.append("passport verdict is not PASS/APPROVED")
    try:
        if args.telemetry:
            if _telemetry_hash(args.telemetry) != passport["evidence"]["telemetry_sha256"]:
                problems.append("telemetry file does not match the hash the passport was issued for")
        if args.report:
            rep = _load(args.report)
            if rep.get("status") != "PASS":
                problems.append("profiler report status is %s" % rep.get("status"))
            elif rep["dataset"]["sha256"] != passport["evidence"]["telemetry_sha256"]:
                problems.append("report and passport reference different datasets")
    except (OSError, ValueError, KeyError) as exc:
        problems.append("cross-check failed: %s" % exc)

    if problems:
        print("PASSPORT REJECTED: " + "; ".join(problems))
        return 1
    print("PASSPORT VERIFIED: build=%s key_id=%s expires=%s"
          % (passport["build_id"], passport["signing"]["key_id"], passport["expires_at"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())

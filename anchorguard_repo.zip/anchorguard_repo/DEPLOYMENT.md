# AnchorGuard — GitLab automation loop: deployment guide

## 1. How the loop works

```mermaid
flowchart LR
    MR[Merge request opened/updated] --> V[validate: profiler_selftest]
    V --> S[shadow-eval: start simulator, sample live, run profiler]
    S -->|PASS| G[compliance-gate: verify signed passport]
    G --> D[deploy-production<br/>default branch only]
    S -->|FAIL: exit 1| X[pipeline fails<br/>gate + deploy blocked]
    X -->|Pipeline events: Failed trigger| F[Duo flow: AnchorGuard Compliance Officer]
    F --> R[branch anchorguard/remediate-mr-IID<br/>+ remediation MR into the MR source branch<br/>+ findings note]
    R -->|human merges| MR
```

The fix is never auto-merged: the flow opens a remediation MR **into the offending MR's source branch**;
merging it re-runs the pipeline, and a clean shadow run produces the passport.

## 2. Repository layout

```text
.
├── .gitlab-ci.yml                                   # pipeline (this guide)
├── AGENTS.md                                        # context + rules for Duo flows
├── .gitlab/duo/
│   ├── mcp.json                                     # MCP client config (IDE / Duo CLI)
│   ├── agents/compliance-officer.md                 # custom agent: prompt + tools (pasted into the UI)
│   └── flows/anchorguard-compliance-officer.yaml    # autonomous custom flow (pasted into the UI)
├── config/runtime_limits.conf                       # the only file remediation may change
├── telemetry_simulator.py   profiler_engine.py   mcp_server.py   # from earlier phases
├── collect_telemetry.py     verify_passport.py                    # new CI helpers
```

## 3. Pipeline setup

| Step | Where | Value |
|---|---|---|
| 1 | Settings → CI/CD → Variables | `ANCHORGUARD_SIGNING_KEY` = long random string. **Masked, not Protected** (MR pipelines on feature branches cannot read protected variables). Forks don't receive it, so fork MRs fail closed. |
| 2 | Settings → Merge requests | Enable **Pipelines must succeed** so a FAIL blocks the merge button. |
| 3 | Settings → Repository → Protected branches | Keep the default branch protected; the flow never needs to push to it. |
| 4 | Optional | `SHADOW_PROFILE=normal` or `anomaly` as a pipeline variable forces the simulated target's behaviour. |

**Shadow target model (mock).** With `SHADOW_PROFILE=auto` the simulated workload is derived from the repo:
`worker_thread_pool_size > 8` in `config/runtime_limits.conf` behaves like the anomaly profile, otherwise normal.
That is what lets the demo close the loop: the remediation lowers the thread pool, the next run is clean.
Replace `collect_telemetry.py` with a real sensor collector for non-demo use.

## 4. Duo setup

### 4.1 Prerequisites
- Duo Agent Platform on; **Allow custom agents** and **Allow custom flows** on (group Settings → GitLab Duo).
- Triggers need Premium or Ultimate.
- Flows run in CI/CD: hosted runners, or your own runners.
- Configure push rules to allow the flow's service account (see GitLab's troubleshooting page for service accounts).

### 4.2 Custom agent (interactive, with MCP)
1. Project → **AI → Agents → New agent**.
2. Copy the name, description, tool list and system prompt from `.gitlab/duo/agents/compliance-officer.md`.
3. **Enable** it in the project, then pick it from the Duo Chat dropdown (UI, VS Code, JetBrains).

### 4.3 MCP bridge (IDE / Duo CLI only)
1. Group Settings → GitLab Duo → **Allow external MCP tools**.
2. Put `.gitlab/duo/mcp.json` in the workspace; replace `cwd` with the repo's absolute path; use an
   absolute `command` path if you see `spawn ... ENOENT`.
3. `pip install "mcp[cli]<2" httpx`, start `python telemetry_simulator.py serve`, restart the IDE.
4. `approvedTools` pre-approves only the read-only `get_build_telemetry` tool.

### 4.4 Autonomous flow (the hands-off part)
1. Project → **AI → Flows → New flow**; paste `.gitlab/duo/flows/anchorguard-compliance-officer.yaml`.
2. **Enable** it in the project. Add trigger: **Pipeline events → Failed**.
3. Note the service account `ai-<flow>-<group>` created for it; it gets the Developer role.
4. Run once from a failing MR and watch **AI → Sessions**.

## 5. Demo script (≈3 minutes)

1. Open an MR that leaves `worker_thread_pool_size = 64` → pipeline: `shadow_evaluation` fails, gate and deploy never run.
2. The flow starts on the failed pipeline, posts the findings note, and opens `anchorguard/remediate-mr<IID>`.
3. Merge the remediation MR into the MR branch → pipeline re-runs → `PASS`, passport verified by `compliance_gate`.
4. Merge to the default branch → `deploy_production` re-verifies the passport and deploys (mock).

Tamper check for judges: edit `anchorguard_out/compliance_passport.json` or swap `telemetry.json` and re-run
`python verify_passport.py ...` → `PASSPORT REJECTED`.

## 6. What was verified, and what needs your eyes

| Item | Status |
|---|---|
| Pipeline logic: FAIL → patch → re-run PASS → gate → deploy; forged passport, swapped telemetry, wrong/missing key all rejected | Executed locally from the job scripts in `.gitlab-ci.yml`, including live 50 Hz polling of the running simulator |
| `.gitlab-ci.yml` syntax / runner behaviour | YAML parses and job scripts run in bash; **not run on a GitLab runner**. Validate once in Build → Pipeline editor → Validate on your first push |
| `mcp.json` format, custom-agent fields, tool names, trigger types, goal payloads | Checked against docs.gitlab.com (GitLab 19.6 docs) |
| Flow `prompts` block and `toolset` field names | **Unverified**: the v1 spec page could not be retrieved. Validate in the flow builder / Execution Console |
| Pipeline-events trigger firing for MR pipelines | Documented as supported; **confirm in your first run** |

## 7. Constraints you should know about

- **Triggers start flows, not custom agents.** That is why the autonomous path is a flow with its own
  condensed prompt; the custom agent covers interactive use and MCP corroboration.
- **Bots cannot trigger flows.** A CI job posting an `@mention` with a project/job token will not start anything;
  trigger events must come from a human action. The Pipeline-events trigger avoids this because the pipeline
  is started by the MR author.
- **MCP is local.** The stdio bridge runs in the IDE/CLI, so the CI flow reads the profiler report from the
  `shadow_evaluation` job log (`ANCHORGUARD_REPORT_BEGIN/END`) instead of calling `get_build_telemetry`.
- **The flow self-filters.** The Failed trigger fires for any failed pipeline; the prompt exits immediately unless the
  failure is `shadow_evaluation` in an MR pipeline. Each firing consumes GitLab Credits.
- **Passports use HMAC** (shared secret). Anyone who can read `ANCHORGUARD_SIGNING_KEY` can forge one; swap in
  Ed25519 if a third party must verify.
- **Thresholds are calibrated to the simulator.** Re-baseline `ProfilerConfig` before pointing this at real hardware.

#!/usr/bin/env python3
"""
Project AnchorGuard - Profiler Engine
=====================================

Evaluates runtime hardware telemetry (as produced by `telemetry_simulator.py`)
against compliance boundaries and decides PASS or FAIL for a build.

  FAIL -> descriptive violation summary + a simulated "hands-off" remediation
          (`remediation_patch.diff` and `remediation_commit_message.txt`).
  PASS -> a signed "Cryptographic Compliance Passport" (`compliance_passport.json`).

Standard library only. Python 3.8+.

Detection model
---------------
Three conditions are evaluated per analysis window (default 10 s) and over the
whole run. Each condition combines an ABSOLUTE compliance boundary with a
STATISTICAL signature detector, because a stealth workload is, by definition,
designed to stay under naive thresholds (the simulator's anomaly averages only
~152 W, well under 158 W):

  1. POWER
       a. mean power_draw_watts > 158 W                       (absolute boundary)
       b. rapid-variance: std of the high-passed power signal  (severe fast swings)
          exceeds a limit
       c. periodic burst: a dominant spectral tone (Goertzel/DFT over a Hann-
          windowed, high-passed signal) with high prominence AND watt amplitude
  2. MEMORY BANDWIDTH
       a. during the burst phase, >= 50 % of samples exceed 0.50 (absolute)
       b. burst-correlated uplift: memory is significantly higher in the burst
          half-cycle than the idle half-cycle (Welch t-test + minimum effect)
  3. HOT CORES
       a. a core's fast-fluctuation spread (p95 - p05 of the high-passed series)
          is disproportionate to the median core, or
       b. a core's mean load sits far above the median core (sustained hotspot)

The `profile` label inside samples is GROUND TRUTH from the simulator and is
never used for the verdict (only reported for evaluation).

Sampling requirement: the high-frequency checks need rate >= `min_rate_hz`
(default 20 Hz). Below that the engine refuses to certify (fail closed).

CLI (CI-friendly exit codes: 0 = PASS, 1 = FAIL, 2 = error)
    python telemetry_simulator.py generate --profile anomaly --duration 60 --rate 50 -o timeline.json
    python profiler_engine.py timeline.json --out-dir ./anchorguard_out --build-id build-1234
"""

import argparse
import difflib
import hashlib
import hmac
import json
import logging
import math
import os
import secrets
import sys
import tempfile
from bisect import bisect_right
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

__version__ = "1.0.0"
LOG = logging.getLogger("anchorguard.profiler")
TWO_PI = 2.0 * math.pi


class TelemetryValidationError(ValueError):
    """Input cannot be analysed (malformed, too short, too coarse). The engine fails closed."""


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ProfilerConfig:
    # --- data requirements ---
    min_samples: int = 100
    min_rate_hz: float = 20.0
    window_s: float = 10.0               # analysis window length
    highpass_window_s: float = 1.0       # moving-average length removed to kill slow drift

    # --- 1. power ---
    power_mean_limit_w: float = 158.0
    power_rapid_std_limit_w: float = 1.5          # ~2x the expected 0.8 W sensor noise
    tone_min_hz: float = 2.0
    tone_max_hz: float = 50.0
    tone_prominence_min: float = 30.0             # peak power / median spectral power
    tone_amplitude_min_w: float = 0.75
    max_spectral_bins: int = 1500

    # --- 2. memory bandwidth ---
    memory_limit: float = 0.50
    memory_over_fraction_min: float = 0.50        # "continuously" over limit in burst phase
    memory_uplift_min: float = 0.03
    memory_uplift_tstat_min: float = 6.0

    # --- 3. hot cores ---
    hot_core_min_cores: int = 3
    hot_core_spread_ratio: float = 1.6
    hot_core_min_excess: float = 0.05
    hot_core_mean_excess: float = 0.30


# --------------------------------------------------------------------------- #
# Small numeric helpers
# --------------------------------------------------------------------------- #
def _mean(xs: Sequence[float]) -> float:
    return sum(xs) / len(xs) if xs else 0.0


def _pstdev(xs: Sequence[float]) -> float:
    if len(xs) < 2:
        return 0.0
    m = _mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))


def _median(xs: Sequence[float]) -> float:
    s = sorted(xs)
    n = len(s)
    if n == 0:
        return 0.0
    return s[n // 2] if n % 2 else 0.5 * (s[n // 2 - 1] + s[n // 2])


def _percentile(xs: Sequence[float], q: float) -> float:
    """Linear-interpolated percentile, q in [0, 100]."""
    s = sorted(xs)
    if not s:
        return 0.0
    pos = (len(s) - 1) * q / 100.0
    lo, hi = int(math.floor(pos)), int(math.ceil(pos))
    return s[lo] + (s[hi] - s[lo]) * (pos - lo)


def _welch_t(a: Sequence[float], b: Sequence[float]) -> float:
    if len(a) < 2 or len(b) < 2:
        return 0.0
    va = sum((x - _mean(a)) ** 2 for x in a) / (len(a) - 1)
    vb = sum((x - _mean(b)) ** 2 for x in b) / (len(b) - 1)
    denom = math.sqrt(va / len(a) + vb / len(b))
    return (_mean(a) - _mean(b)) / denom if denom > 0 else 0.0


def _highpass(x: Sequence[float], length: int) -> List[float]:
    """x minus a centred moving average (O(n) via prefix sums); removes slow drift."""
    n = len(x)
    h = max(1, length // 2)
    prefix = [0.0]
    for v in x:
        prefix.append(prefix[-1] + v)
    out = []
    for i in range(n):
        lo, hi = max(0, i - h), min(n, i + h + 1)
        out.append(x[i] - (prefix[hi] - prefix[lo]) / (hi - lo))
    return out


def _longest_run(flags: Sequence[bool]) -> int:
    best = cur = 0
    for f in flags:
        cur = cur + 1 if f else 0
        best = max(best, cur)
    return best


# --------------------------------------------------------------------------- #
# Spectral tone detection
# --------------------------------------------------------------------------- #
def _goertzel_power(x: Sequence[float], rate: float, freq: float) -> float:
    """|DFT|^2 of x at `freq` Hz via the Goertzel recurrence (one MAC per sample)."""
    coeff = 2.0 * math.cos(TWO_PI * freq / rate)
    s1 = s2 = 0.0
    for v in x:
        s0 = v + coeff * s1 - s2
        s2, s1 = s1, s0
    return max(0.0, s1 * s1 + s2 * s2 - coeff * s1 * s2)


def _detect_tone(x: Sequence[float], rate: float, cfg: ProfilerConfig) -> Optional[Dict[str, Any]]:
    """
    Find the dominant periodic component of a (high-passed) signal.

    Math: with a Hann window w[n], a pure tone A*cos(2*pi*f*n/rate + phi) produces a
    DFT magnitude |X(f)| = A * sum(w) / 2, so amplitude A = 2|X| / sum(w). The
    prominence is peak power over the MEDIAN power of the scanned band: for white
    noise this is ~5-10, while a real periodic burst is orders of magnitude higher.
    """
    n = len(x)
    if n < 64:
        return None
    f_lo, f_hi = cfg.tone_min_hz, min(cfg.tone_max_hz, 0.45 * rate)
    if f_hi <= f_lo:
        return None
    mean = _mean(x)
    win = [0.5 - 0.5 * math.cos(TWO_PI * i / (n - 1)) for i in range(n)]
    xw = [(v - mean) * w for v, w in zip(x, win)]
    wsum = sum(win)

    duration = n / rate
    step = max(0.5 / duration, (f_hi - f_lo) / cfg.max_spectral_bins)
    freqs, powers = [], []
    f = f_lo
    while f <= f_hi:
        freqs.append(f)
        powers.append(_goertzel_power(xw, rate, f))
        f += step
    floor = _median(powers)
    k = max(range(len(powers)), key=powers.__getitem__)
    prominence = powers[k] / floor if floor > 0 else float("inf")
    f0 = freqs[k]

    # Complex projection at f0 gives the phase, used to label burst half-cycles.
    w0 = TWO_PI * f0 / rate
    re = sum(v * math.cos(w0 * i) for i, v in enumerate(xw))
    im = -sum(v * math.sin(w0 * i) for i, v in enumerate(xw))
    return {
        "freq_hz": f0,
        "amplitude": 2.0 * math.sqrt(powers[k]) / wsum,
        "prominence": prominence,
        "phase": math.atan2(im, re),
        "omega": w0,
        "detected": (prominence >= cfg.tone_prominence_min
                     and 2.0 * math.sqrt(powers[k]) / wsum >= cfg.tone_amplitude_min_w),
    }


# --------------------------------------------------------------------------- #
# Input validation / normalisation
# --------------------------------------------------------------------------- #
@dataclass
class _Series:
    t: List[float]
    power: List[float]
    mem: List[float]
    cores: List[List[float]]      # [core][time]
    rate: float
    labels: Dict[str, int]


def _num(value: Any, name: str, idx: int) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise TelemetryValidationError("sample %d: %s is not numeric" % (idx, name))
    if not math.isfinite(v):
        raise TelemetryValidationError("sample %d: %s is not finite" % (idx, name))
    return v


def _prepare(samples: Sequence[Dict[str, Any]], cfg: ProfilerConfig) -> _Series:
    if not isinstance(samples, (list, tuple)) or len(samples) < cfg.min_samples:
        raise TelemetryValidationError(
            "need at least %d samples to profile a build (got %s)"
            % (cfg.min_samples, len(samples) if hasattr(samples, "__len__") else "?"))
    rows = []
    n_cores: Optional[int] = None
    t_first = None
    labels: Dict[str, int] = {}
    for i, s in enumerate(samples):
        if not isinstance(s, dict):
            raise TelemetryValidationError("sample %d is not an object" % i)
        try:
            raw_cores = s["cpu_cycle_distribution"]
            pw, mem = s["power_draw_watts"], s["memory_bandwidth_utilization"]
        except KeyError as exc:
            raise TelemetryValidationError("sample %d missing field %s" % (i, exc))
        if "t_offset_s" in s:
            t = _num(s["t_offset_s"], "t_offset_s", i)
        elif "timestamp" in s:
            ts = _num(s["timestamp"], "timestamp", i)
            t_first = ts if t_first is None else t_first
            t = ts - t_first
        else:
            raise TelemetryValidationError("sample %d has no t_offset_s or timestamp" % i)
        cores = [_num(c, "cpu core load", i) for c in raw_cores]
        if n_cores is None:
            n_cores = len(cores)
            if n_cores < 1:
                raise TelemetryValidationError("sample 0 has no CPU cores")
        elif len(cores) != n_cores:
            raise TelemetryValidationError("sample %d: inconsistent core count" % i)
        pw, mem = _num(pw, "power_draw_watts", i), _num(mem, "memory_bandwidth_utilization", i)
        if pw < 0 or not 0.0 <= mem <= 1.0 or any(not 0.0 <= c <= 1.0 for c in cores):
            raise TelemetryValidationError("sample %d has physically invalid values" % i)
        rows.append((t, pw, mem, cores))
        lab = s.get("profile")
        if isinstance(lab, str):
            labels[lab] = labels.get(lab, 0) + 1

    rows.sort(key=lambda r: r[0])
    rows = [r for j, r in enumerate(rows) if j == 0 or r[0] > rows[j - 1][0]]   # drop duplicate times
    if len(rows) < cfg.min_samples:
        raise TelemetryValidationError("too few distinct timestamps after de-duplication")
    t = [r[0] for r in rows]
    dts = [b - a for a, b in zip(t, t[1:])]
    med_dt = _median(dts)
    if med_dt <= 0:
        raise TelemetryValidationError("cannot determine sample rate")
    rate = 1.0 / med_dt
    if rate < cfg.min_rate_hz:
        raise TelemetryValidationError(
            "sample rate %.1f Hz is below the %.1f Hz minimum; high-frequency bursts cannot be "
            "ruled out, so the build cannot be certified. Re-sample faster." % (rate, cfg.min_rate_hz))

    cols = [[r[1] for r in rows], [r[2] for r in rows]] + [[r[3][c] for r in rows] for c in range(n_cores or 0)]
    if max(abs(d - med_dt) for d in dts) / med_dt > 0.05:       # irregular spacing -> resample
        n = int(math.floor((t[-1] - t[0]) * rate)) + 1
        grid = [t[0] + i / rate for i in range(n)]
        new_cols = []
        for col in cols:
            out = []
            for g in grid:
                j = min(max(bisect_right(t, g) - 1, 0), len(t) - 2)
                span = t[j + 1] - t[j]
                a = (g - t[j]) / span if span > 0 else 0.0
                out.append(col[j] + (col[j + 1] - col[j]) * min(max(a, 0.0), 1.0))
            new_cols.append(out)
        cols, t = new_cols, grid
    return _Series(t=t, power=cols[0], mem=cols[1], cores=cols[2:], rate=rate, labels=labels)


# --------------------------------------------------------------------------- #
# Window analysis
# --------------------------------------------------------------------------- #
def _analyze_window(ser: _Series, hp: Dict[str, Any], a: int, b: int,
                    cfg: ProfilerConfig) -> Dict[str, Any]:
    rate = ser.rate
    p_raw, p_hp = ser.power[a:b], hp["power"][a:b]
    m_raw, m_hp = ser.mem[a:b], hp["mem"][a:b]

    # ---- 1. power ------------------------------------------------------- #
    mean_p = _mean(p_raw)
    rapid_std = _pstdev(p_hp)
    tone = _detect_tone(p_hp, rate, cfg)
    tone_ok = bool(tone and tone["detected"])
    power_flags = {
        "mean_over_limit": mean_p > cfg.power_mean_limit_w,
        "rapid_variance": rapid_std > cfg.power_rapid_std_limit_w,
        "periodic_burst": tone_ok,
    }
    power_score = max(
        mean_p / cfg.power_mean_limit_w,
        rapid_std / cfg.power_rapid_std_limit_w,
        min(tone["prominence"] / cfg.tone_prominence_min, tone["amplitude"] / cfg.tone_amplitude_min_w) if tone else 0.0)

    # ---- 2. memory ------------------------------------------------------ #
    if tone_ok:
        mask = [math.cos(tone["omega"] * i + tone["phase"]) > 0 for i in range(b - a)]
    else:
        mask = [True] * (b - a)                       # no identifiable burst: judge the whole window
    pool = [m for m, k in zip(m_raw, mask) if k]
    frac_over = sum(1 for m in pool if m > cfg.memory_limit) / len(pool) if pool else 0.0
    uplift = tstat = 0.0
    if tone_ok:
        burst = [m for m, k in zip(m_hp, mask) if k]
        idle = [m for m, k in zip(m_hp, mask) if not k]
        uplift, tstat = _mean(burst) - _mean(idle), _welch_t(burst, idle)
    mem_flags = {
        "over_limit_in_burst": frac_over >= cfg.memory_over_fraction_min,
        "burst_correlated_uplift": (tone_ok and uplift >= cfg.memory_uplift_min
                                    and tstat >= cfg.memory_uplift_tstat_min),
    }
    mem_score = max(frac_over / cfg.memory_over_fraction_min,
                    min(uplift / cfg.memory_uplift_min, tstat / cfg.memory_uplift_tstat_min) if tone_ok else 0.0)

    # ---- 3. hot cores --------------------------------------------------- #
    n_cores = len(ser.cores)
    hot: List[int] = []
    spreads: List[float] = []
    means: List[float] = []
    ratio_score = 0.0
    if n_cores >= cfg.hot_core_min_cores:
        spreads = [_percentile(c[a:b], 95) - _percentile(c[a:b], 5) for c in hp["cores"]]
        means = [_mean(c[a:b]) for c in ser.cores]
        med_spread, med_mean = _median(spreads), _median(means)
        for i in range(n_cores):
            spike = (med_spread > 0 and spreads[i] >= cfg.hot_core_spread_ratio * med_spread
                     and spreads[i] - med_spread >= cfg.hot_core_min_excess)
            sustained = means[i] - med_mean >= cfg.hot_core_mean_excess
            if spike or sustained:
                hot.append(i)
            if med_spread > 0:
                ratio_score = max(ratio_score, min(spreads[i] / (cfg.hot_core_spread_ratio * med_spread),
                                                   (spreads[i] - med_spread) / cfg.hot_core_min_excess))
            ratio_score = max(ratio_score, (means[i] - med_mean) / cfg.hot_core_mean_excess)
    core_flags = {"hot_cores_detected": bool(hot)}

    return {
        "start_s": round(ser.t[a] - ser.t[0], 3), "end_s": round(ser.t[b - 1] - ser.t[0], 3),
        "power": {"flags": power_flags, "violated": any(power_flags.values()), "score": power_score,
                  "mean_w": mean_p, "rapid_std_w": rapid_std,
                  "tone_hz": tone["freq_hz"] if tone else None,
                  "tone_amplitude_w": tone["amplitude"] if tone else None,
                  "tone_prominence": tone["prominence"] if tone else None},
        "memory": {"flags": mem_flags, "violated": any(mem_flags.values()), "score": mem_score,
                   "fraction_over_limit_in_burst": frac_over, "burst_uplift": uplift,
                   "uplift_t_stat": tstat, "mean": _mean(m_raw), "peak": max(m_raw),
                   "longest_run_over_limit_s": _longest_run([m > cfg.memory_limit for m in m_raw]) / rate},
        "cores": {"flags": core_flags, "violated": bool(hot), "score": ratio_score, "hot_cores": hot,
                  "fast_spread_per_core": spreads, "mean_load_per_core": means},
    }


def _segments(n: int, rate: float, cfg: ProfilerConfig) -> List[Tuple[int, int]]:
    w = max(int(cfg.window_s * rate), 64)
    if n < int(1.5 * w):
        return [(0, n)]
    cuts = list(range(0, n - w + 1, w))
    segs = [(c, c + w) for c in cuts]
    if n - segs[-1][1] >= w // 2:
        segs.append((segs[-1][1], n))
    else:
        segs[-1] = (segs[-1][0], n)
    return segs


# --------------------------------------------------------------------------- #
# Public: baseline checker
# --------------------------------------------------------------------------- #
def _canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _r(x: Any, nd: int = 4) -> Any:
    if isinstance(x, float):
        return round(x, nd) if math.isfinite(x) else None
    if isinstance(x, dict):
        return {k: _r(v, nd) for k, v in x.items()}
    if isinstance(x, list):
        return [_r(v, nd) for v in x]
    return x


def check_baseline(samples: List[Dict[str, Any]],
                   config: Optional[ProfilerConfig] = None) -> Dict[str, Any]:
    """
    Evaluate a list of telemetry sample dicts. Returns a JSON-serialisable report with
    `status` ('PASS' | 'FAIL'), a descriptive `summary`, per-condition evidence, per-window
    results and the first violation offset. Raises TelemetryValidationError if the data
    cannot be analysed (the engine never certifies data it cannot interpret).
    """
    cfg = config or ProfilerConfig()
    ser = _prepare(samples, cfg)
    n, rate = len(ser.power), ser.rate
    L = max(3, int(cfg.highpass_window_s * rate) | 1)
    hp = {"power": _highpass(ser.power, L), "mem": _highpass(ser.mem, L),
          "cores": [_highpass(c, L) for c in ser.cores]}

    windows = [_analyze_window(ser, hp, a, b, cfg) for a, b in _segments(n, rate, cfg)]
    whole = windows[0] if len(windows) == 1 else _analyze_window(ser, hp, 0, n, cfg)
    candidates = windows + ([] if len(windows) == 1 else [whole])

    def worst(key: str) -> Dict[str, Any]:
        viol = [w for w in candidates if w[key]["violated"]]
        return max(viol or candidates, key=lambda w: w[key]["score"])[key]

    conditions = {k: dict(worst(k), violated=any(w[k]["violated"] for w in candidates))
                  for k in ("power", "memory", "cores")}
    failed = [k for k, v in conditions.items() if v["violated"]]
    if not failed:   # clean run: report whole-run figures, not the "worst" window's
        conditions = {k: dict(whole[k], violated=False) for k in ("power", "memory", "cores")}
    first = next((w["start_s"] for w in windows if any(w[k]["violated"] for k in conditions)), None)

    classification = "CLEAN"
    if failed:
        tone = conditions["power"]["flags"]["periodic_burst"]
        corr = conditions["memory"]["flags"]["burst_correlated_uplift"] or conditions["cores"]["violated"]
        classification = "CRYPTOJACKING_SUSPECTED" if (tone and corr) else "COMPUTE_ABNORMALITY"

    report = {
        "engine_version": __version__,
        "status": "FAIL" if failed else "PASS",
        "classification": classification,
        "violated_conditions": failed,
        "first_violation_offset_s": first,
        "summary": _summarize(conditions, classification, first, cfg),
        "dataset": {"sample_count": len(samples), "analysed_samples": n,
                    "duration_s": round(ser.t[-1] - ser.t[0], 3), "sample_rate_hz": round(rate, 3),
                    "cores": len(ser.cores), "windows": len(windows),
                    "sha256": hashlib.sha256(_canonical(list(samples))).hexdigest(),
                    "ground_truth_labels_NOT_USED_FOR_VERDICT": ser.labels},
        "conditions": _r(conditions),
        "windows": _r([{"start_s": w["start_s"], "end_s": w["end_s"],
                        "violations": [k for k in ("power", "memory", "cores") if w[k]["violated"]]}
                       for w in windows]),
        "thresholds": asdict(cfg),
        "limitations": [
            "Statistical screening of telemetry, not proof of intent; thresholds are calibrated to the "
            "AnchorGuard simulator and must be re-baselined for real hardware.",
            "Hot-core detection compares cores to each other; a workload that loads every core "
            "identically is only caught by the power/memory checks.",
        ],
    }
    return report


def _summarize(c: Dict[str, Any], classification: str, first: Optional[float],
               cfg: ProfilerConfig) -> str:
    if classification == "CLEAN":
        p, m = c["power"], c["memory"]
        return ("Telemetry within compliance boundaries: mean power %.1f W (limit %.0f W), rapid-variance "
                "std %.2f W, no dominant periodic burst, peak memory bandwidth %.2f, no hot cores."
                % (p["mean_w"], cfg.power_mean_limit_w, p["rapid_std_w"], m["peak"]))
    parts = []
    p, m, k = c["power"], c["memory"], c["cores"]
    pf = p["flags"]
    if pf["periodic_burst"]:
        head = ("High-frequency compute spike (%.2f Hz periodic burst, %.1f W tone, %.0fx spectral prominence)"
                % (p["tone_hz"], p["tone_amplitude_w"], p["tone_prominence"]))
        head += (" matching crypto-jacking profile" if classification == "CRYPTOJACKING_SUSPECTED"
                 else " indicating hidden cyclic compute")
        parts.append(head)
    if pf["mean_over_limit"]:
        parts.append("mean power %.1f W exceeds the %.0f W limit" % (p["mean_w"], cfg.power_mean_limit_w))
    if pf["rapid_variance"]:
        parts.append("rapid power variance %.2f W exceeds %.2f W" % (p["rapid_std_w"], cfg.power_rapid_std_limit_w))
    if m["flags"]["burst_correlated_uplift"]:
        parts.append("memory bandwidth rises %.3f in the burst phase (t=%.1f)" % (m["burst_uplift"], m["uplift_t_stat"]))
    if m["flags"]["over_limit_in_burst"]:
        parts.append("memory bandwidth above %.2f in %.0f%% of burst-phase samples"
                     % (cfg.memory_limit, 100 * m["fraction_over_limit_in_burst"]))
    if k["violated"]:
        parts.append("disproportionate load on core(s) %s" % ", ".join(str(i) for i in k["hot_cores"]))
    text = "; ".join(parts)
    text = text[0].upper() + text[1:] + "."
    if first is not None:
        text += " First observed in the window starting at t=%.1f s." % first
    return text


# --------------------------------------------------------------------------- #
# FAIL path: simulated hands-off remediation
# --------------------------------------------------------------------------- #
MOCK_CONFIG_PATH = "config/runtime_limits.conf"
STANDARD_THREADS = 8
MOCK_RUNTIME_CONFIG = (
    "# Runtime resource limits for the build workload (mock file for AnchorGuard demo)\n"
    "worker_thread_pool_size = 64\n"
    "max_cpu_percent_per_core = 100\n"
    "memory_bandwidth_cap_percent = 100\n"
    "power_cap_watts = 0\n"
)


def _atomic_write(path: str, text: str) -> None:
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".ag_", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def generate_remediation_patch(report: Dict[str, Any], output_dir: str = ".",
                               config_path: str = MOCK_CONFIG_PATH,
                               build_id: str = "unknown") -> Dict[str, str]:
    """
    SIMULATED autonomous remediation. Writes (never applies) a git-style patch that lowers
    the heavy thread-pool constraint to standard parameters, and caps per-core CPU, memory
    bandwidth and power according to which conditions failed, plus a commit message.
    The patch applies cleanly to MOCK_RUNTIME_CONFIG (`git apply --check`).
    """
    if report.get("status") != "FAIL":
        raise ValueError("remediation is only generated for FAIL reports")
    failed = set(report["violated_conditions"])
    after = MOCK_RUNTIME_CONFIG.replace("worker_thread_pool_size = 64",
                                        "worker_thread_pool_size = %d" % STANDARD_THREADS)
    changes = ["worker_thread_pool_size: 64 -> %d" % STANDARD_THREADS]
    if "cores" in failed:
        after = after.replace("max_cpu_percent_per_core = 100", "max_cpu_percent_per_core = 60")
        changes.append("max_cpu_percent_per_core: 100 -> 60")
    if "memory" in failed:
        after = after.replace("memory_bandwidth_cap_percent = 100", "memory_bandwidth_cap_percent = 45")
        changes.append("memory_bandwidth_cap_percent: 100 -> 45")
    if "power" in failed:
        after = after.replace("power_cap_watts = 0", "power_cap_watts = 155")
        changes.append("power_cap_watts: 0 -> 155")

    diff_body = "".join(difflib.unified_diff(
        MOCK_RUNTIME_CONFIG.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile="a/" + config_path, tofile="b/" + config_path, lineterm="\n"))
    patch = "diff --git a/%s b/%s\n%s" % (config_path, config_path, diff_body)

    message = (
        "fix(runtime): throttle anomalous compute workload [AnchorGuard auto-remediation]\n\n"
        "%s\n\nChanges:\n%s\n\n"
        "Build: %s\nTelemetry SHA-256: %s\n"
        "Auto-Remediation: AnchorGuard (SIMULATED - not applied, human review required)\n"
        % (report["summary"], "\n".join("  - " + c for c in changes), build_id, report["dataset"]["sha256"]))

    patch_path = os.path.join(output_dir, "remediation_patch.diff")
    msg_path = os.path.join(output_dir, "remediation_commit_message.txt")
    _atomic_write(patch_path, patch)
    _atomic_write(msg_path, message)
    return {"patch": patch_path, "commit_message": msg_path}


# --------------------------------------------------------------------------- #
# PASS path: Cryptographic Compliance Passport
# --------------------------------------------------------------------------- #
def _resolve_key(signing_key: Optional[bytes]) -> Tuple[bytes, str]:
    if signing_key:
        return signing_key, "argument"
    env = os.environ.get("ANCHORGUARD_SIGNING_KEY")
    if env:
        return env.encode("utf-8"), "environment"
    LOG.warning("ANCHORGUARD_SIGNING_KEY not set: using an EPHEMERAL key; this passport cannot be "
                "verified after this process exits.")
    return secrets.token_bytes(32), "ephemeral"


def issue_compliance_passport(report: Dict[str, Any], signing_key: Optional[bytes] = None,
                              build_id: str = "unknown", ttl_hours: float = 24.0,
                              now: Optional[datetime] = None) -> Dict[str, Any]:
    """
    Issue a signed passport for a PASS report. Signature = HMAC-SHA256 over the canonical JSON
    of the passport body. NOTE: HMAC is symmetric - the verifier needs the same secret key. For
    third-party verifiability swap in an asymmetric scheme (e.g. Ed25519 via `cryptography`).
    """
    if report.get("status") != "PASS":
        raise ValueError("a passport is only issued for PASS reports")
    key, source = _resolve_key(signing_key)
    issued = (now or datetime.now(timezone.utc)).replace(microsecond=0)
    c = report["conditions"]
    body = {
        "passport_version": "1.0",
        "type": "AnchorGuard Cryptographic Compliance Passport",
        "build_id": build_id,
        "verdict": "PASS",
        "production_gate": "APPROVED",
        "issued_at": issued.isoformat(),
        "expires_at": (issued + timedelta(hours=ttl_hours)).isoformat(),
        "nonce": secrets.token_hex(8),
        "evidence": {
            "telemetry_sha256": report["dataset"]["sha256"],
            "sample_count": report["dataset"]["sample_count"],
            "duration_s": report["dataset"]["duration_s"],
            "sample_rate_hz": report["dataset"]["sample_rate_hz"],
            "mean_power_w": c["power"]["mean_w"],
            "rapid_power_std_w": c["power"]["rapid_std_w"],
            "peak_memory_bandwidth": c["memory"]["peak"],
            "thresholds": report["thresholds"],
            "engine_version": report["engine_version"],
        },
        "signing": {"algorithm": "HMAC-SHA256", "key_source": source,
                    "key_id": hmac.new(key, b"anchorguard-key-id", hashlib.sha256).hexdigest()[:12]},
    }
    signature = hmac.new(key, _canonical(body), hashlib.sha256).hexdigest()
    return dict(body, signature=signature)


def verify_passport(passport: Dict[str, Any], signing_key: bytes,
                    now: Optional[datetime] = None) -> Tuple[bool, str]:
    """Check signature integrity and expiry. Returns (ok, reason)."""
    body = {k: v for k, v in passport.items() if k != "signature"}
    expected = hmac.new(signing_key, _canonical(body), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, str(passport.get("signature", ""))):
        return False, "signature mismatch (tampered passport or wrong key)"
    try:
        expires = datetime.fromisoformat(passport["expires_at"])
    except (KeyError, ValueError):
        return False, "missing or invalid expiry"
    if (now or datetime.now(timezone.utc)) > expires:
        return False, "passport expired"
    return True, "valid"


# --------------------------------------------------------------------------- #
# Orchestration + CLI
# --------------------------------------------------------------------------- #
def load_telemetry_samples(path: str) -> List[Dict[str, Any]]:
    """Load a JSON file from `telemetry_simulator.py generate` ({'metadata','samples'}) or a bare list."""
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    samples = data.get("samples") if isinstance(data, dict) else data
    if not isinstance(samples, list):
        raise TelemetryValidationError("%s has no 'samples' list" % path)
    return samples


def run_profiler(samples: List[Dict[str, Any]], output_dir: str = "anchorguard_out",
                 build_id: str = "unknown", signing_key: Optional[bytes] = None,
                 config: Optional[ProfilerConfig] = None,
                 config_path: str = MOCK_CONFIG_PATH) -> Dict[str, Any]:
    """Run the check, then emit remediation artifacts (FAIL) or a passport (PASS)."""
    report = check_baseline(samples, config)
    artifacts: Dict[str, str] = {}
    passport = None
    if report["status"] == "FAIL":
        artifacts = generate_remediation_patch(report, output_dir, config_path, build_id)
    else:
        passport = issue_compliance_passport(report, signing_key, build_id)
        artifacts["passport"] = os.path.join(output_dir, "compliance_passport.json")
        _atomic_write(artifacts["passport"], json.dumps(passport, indent=2) + "\n")
    artifacts["report"] = os.path.join(output_dir, "profiler_report.json")
    _atomic_write(artifacts["report"], json.dumps(report, indent=2) + "\n")
    return {"report": report, "artifacts": artifacts, "passport": passport}


def main(argv: Optional[List[str]] = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s", stream=sys.stderr)
    ap = argparse.ArgumentParser(description="AnchorGuard profiler: PASS/FAIL a telemetry timeline.")
    ap.add_argument("dataset", help="JSON file produced by `telemetry_simulator.py generate`")
    ap.add_argument("--out-dir", default="anchorguard_out")
    ap.add_argument("--build-id", default=os.environ.get("CI_PIPELINE_ID", "local"))
    args = ap.parse_args(argv)
    try:
        result = run_profiler(load_telemetry_samples(args.dataset), args.out_dir, args.build_id)
    except (OSError, ValueError) as exc:        # includes JSON errors and TelemetryValidationError
        LOG.error("%s", exc)
        return 2
    rep = result["report"]
    print("STATUS: %s (%s)" % (rep["status"], rep["classification"]))
    print(rep["summary"])
    for name, path in result["artifacts"].items():
        print("  wrote %-14s %s" % (name + ":", path))
    return 0 if rep["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())

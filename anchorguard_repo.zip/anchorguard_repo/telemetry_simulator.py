#!/usr/bin/env python3
"""
Project AnchorGuard - Runtime Hardware Telemetry Simulator
===========================================================

Synthesises physical side-channel metrics (power draw, per-core CPU load, memory
bandwidth) of an executing application build so that anomaly-detection logic can
be exercised without real malware or hardware probes.

Two behavioural profiles:

  normal   Stable ~150 W baseline, slow/predictable drift, Gaussian sensor noise.
  anomaly  "normal" PLUS a subtle, high-frequency, soft-squared burst riding on
           power draw and memory bandwidth, with a correlated bump on a subset
           of CPU cores (an unauthorised background crypto / compute workload).

Usage
-----
  # Live HTTP endpoint (127.0.0.1:8000 by default)
  python telemetry_simulator.py serve
  curl 'http://127.0.0.1:8000/metrics?profile=anomaly&cores=8'
  curl 'http://127.0.0.1:8000/health'

  # Offline timeline written to disk
  python telemetry_simulator.py generate --profile anomaly --duration 60 \\
         --rate 50 --seed 42 --output timeline.json

  # Labelled timeline: normal for 30 s, then the anomaly switches on
  python telemetry_simulator.py generate --profile anomaly --anomaly-after 30 \\
         --duration 90 --rate 50 --output labelled.json

Requirements: Python 3.8+, standard library only.
"""

import argparse
import json
import logging
import math
import os
import random
import secrets
import sys
import tempfile
import threading
import time
from dataclasses import asdict, dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

__version__ = "1.0.0"

LOG = logging.getLogger("anchorguard.telemetry")

PROFILES = ("normal", "anomaly")
DEFAULT_CORES = 8
MAX_CORES = 256                # sanity cap for the HTTP query parameter
MAX_TIMELINE_SAMPLES = 10_000_000
TWO_PI = 2.0 * math.pi


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class SimulationConfig:
    """All tunable physical constants in one immutable place."""

    # --- Power (watts) ---------------------------------------------------- #
    base_power_w: float = 150.0
    power_slow_amp_w: float = 3.0          # slow thermal / DVFS drift
    power_slow_period_s: float = 30.0
    power_harm_amp_w: float = 1.5          # secondary periodic activity (GC, I/O)
    power_harm_period_s: float = 7.0
    power_noise_sigma_w: float = 0.8       # sensor / measurement noise

    # --- Memory bandwidth (fraction of peak) ------------------------------ #
    mem_base: float = 0.35
    mem_slow_amp: float = 0.03
    mem_slow_period_s: float = 21.0
    mem_noise_sigma: float = 0.012

    # --- CPU (fraction of core capacity) ---------------------------------- #
    cpu_base_range: Tuple[float, float] = (0.22, 0.42)
    cpu_slow_amp: float = 0.04
    cpu_slow_period_s: float = 25.0
    cpu_noise_sigma: float = 0.02

    # --- Anomaly: burst envelope shape ------------------------------------ #
    burst_freq_hz: float = 5.0             # cycles per second
    burst_duty: float = 0.5                # fraction of each cycle that is "high"
    burst_sharpness: float = 4.0           # k in tanh(k * ...); higher => squarer
    burst_amp_jitter: float = 0.10         # slow +/-10 % amplitude wander

    # --- Anomaly: burst amplitudes ---------------------------------------- #
    power_burst_amp_w: float = 3.5         # ~4x the noise sigma: subtle but real
    mem_burst_amp: float = 0.08
    mem_burst_phase_rad: float = 0.35      # memory lags the power rail slightly
    cpu_burst_amp: float = 0.12
    cpu_burst_core_fraction: float = 0.25  # share of cores that host the workload


# --------------------------------------------------------------------------- #
# Cyclic burst envelope
# --------------------------------------------------------------------------- #
def burst_envelope(t: float, freq_hz: float, duty: float, sharpness: float,
                   phase: float = 0.0) -> float:
    """
    Smooth ("soft") square wave in [0, 1], built from sin() and tanh().

    Why not a hard square wave?
        Real workloads do not toggle power instantly: voltage regulators, bulk
        capacitance and thermal mass low-pass the edges. A hard square also
        injects an unrealistic infinite harmonic series. We want clean, band-
        limited-looking edges, which tanh provides.

    Construction
        1. Carrier:       s(t) = sin(2*pi*f*t + phase)          in [-1, 1]
        2. Hard-limit:    sign(s(t) - c)  would give a square wave.
        3. Soften:        q(t) = tanh(k * (s(t) - c))            in (-1, 1)
                          tanh is a smooth, monotone sigmoid, so as k grows
                          q(t) approaches sign(s - c) but with a finite slope
                          at the zero crossings (edge width ~ 1/k of the
                          carrier amplitude).
        4. Rescale:       e(t) = (1 + q(t)) / 2                  in (0, 1)

    Duty-cycle control (the offset c)
        The envelope is "high" while sin(theta) > c. Over one period that is
        the fraction  (pi - 2*asin(c)) / (2*pi)  of the cycle. Setting that
        equal to the desired duty d and solving gives
                          c = cos(pi * d)
        so d = 0.5 -> c = 0 (symmetric), d -> 0 -> c -> 1 (short pulses),
        d -> 1 -> c -> -1 (mostly on).

    Spectrum
        The result has a fundamental at `freq_hz` plus odd harmonics that roll
        off smoothly - the spectral "fingerprint" a side-channel detector
        (FFT / Welch PSD / autocorrelation) should be able to find.

    Note on sampling
        Detection requires sampling faster than Nyquist: rate >= 2 * freq_hz.
    """
    carrier = math.sin(TWO_PI * freq_hz * t + phase)
    c = math.cos(math.pi * duty)
    e = 0.5 * (1.0 + math.tanh(sharpness * (carrier - c)))
    return min(1.0, max(0.0, e))


def _clamp01(x: float) -> float:
    return 0.0 if x < 0.0 else 1.0 if x > 1.0 else x


# --------------------------------------------------------------------------- #
# Generator
# --------------------------------------------------------------------------- #
class TelemetryGenerator:
    """
    Thread-safe, seedable telemetry source.

    * One lock guards the shared RNG and the layout cache, so concurrent HTTP
      handler threads never interleave RNG draws within a single sample.
    * For a fixed seed AND explicit (t_offset, timestamp) arguments, the output
      is fully reproducible (single-threaded). In live mode the time axis comes
      from the clock, so only the per-core layout is reproducible.
    * Per-core layout (base loads, phases, which cores host the hidden workload)
      is derived from `Random("<seed>:layout:<n_cores>")`, so it is stable per
      core count and independent of call order.
    """

    def __init__(self, seed: Optional[int] = None, num_cores: int = DEFAULT_CORES,
                 config: Optional[SimulationConfig] = None) -> None:
        if not 1 <= num_cores <= MAX_CORES:
            raise ValueError("num_cores must be between 1 and %d" % MAX_CORES)
        self.seed: int = secrets.randbits(32) if seed is None else int(seed)
        self.default_cores = num_cores
        self.config = config or SimulationConfig()
        self._rng = random.Random(self.seed)
        self._lock = threading.Lock()
        self._layouts: Dict[int, Dict[str, Any]] = {}
        self._mono0 = time.monotonic()
        self._epoch0 = time.time()

    # -- helpers ---------------------------------------------------------- #
    @property
    def uptime_s(self) -> float:
        return time.monotonic() - self._mono0

    def _layout(self, n: int) -> Dict[str, Any]:
        """Per-core constants for an n-core machine (call with lock held)."""
        layout = self._layouts.get(n)
        if layout is None:
            cfg = self.config
            r = random.Random("%d:layout:%d" % (self.seed, n))
            k = max(1, int(round(n * cfg.cpu_burst_core_fraction)))
            burst_cores = set(r.sample(range(n), min(k, n)))
            layout = {
                "base": [r.uniform(*cfg.cpu_base_range) for _ in range(n)],
                "phase": [r.uniform(0.0, TWO_PI) for _ in range(n)],
                # Each hijacked core carries a slightly different share of the load.
                "burst_gain": [
                    cfg.cpu_burst_amp * r.uniform(0.8, 1.2) if i in burst_cores else 0.0
                    for i in range(n)
                ],
            }
            self._layouts[n] = layout
        return layout

    # -- public API ------------------------------------------------------- #
    def sample(self, profile: str = "normal", t_offset: Optional[float] = None,
               timestamp: Optional[float] = None,
               num_cores: Optional[int] = None) -> Dict[str, Any]:
        """Return one telemetry packet (see module docstring for the schema)."""
        if profile not in PROFILES:
            raise ValueError("profile must be one of %s" % (PROFILES,))
        n = self.default_cores if num_cores is None else int(num_cores)
        if not 1 <= n <= MAX_CORES:
            raise ValueError("cores must be between 1 and %d" % MAX_CORES)

        cfg = self.config
        with self._lock:
            if t_offset is None:
                t_offset = time.monotonic() - self._mono0
                if timestamp is None:
                    timestamp = time.time()
            elif timestamp is None:
                timestamp = self._epoch0 + t_offset
            t = float(t_offset)

            layout = self._layout(n)
            gauss = self._rng.gauss

            # ---- Shared burst envelope (anomaly only) -------------------- #
            anomalous = profile == "anomaly"
            if anomalous:
                env_power = burst_envelope(t, cfg.burst_freq_hz, cfg.burst_duty,
                                           cfg.burst_sharpness)
                env_mem = burst_envelope(t, cfg.burst_freq_hz, cfg.burst_duty,
                                         cfg.burst_sharpness, cfg.mem_burst_phase_rad)
                # Slow amplitude wander makes the burst look less machine-perfect.
                wander = 1.0 + cfg.burst_amp_jitter * math.sin(TWO_PI * 0.13 * t + 1.1)
            else:
                env_power = env_mem = 0.0
                wander = 1.0

            # ---- Power --------------------------------------------------- #
            power = (cfg.base_power_w
                     + cfg.power_slow_amp_w * math.sin(TWO_PI * t / cfg.power_slow_period_s + 0.7)
                     + cfg.power_harm_amp_w * math.sin(TWO_PI * t / cfg.power_harm_period_s + 2.1)
                     + gauss(0.0, cfg.power_noise_sigma_w))
            if anomalous:
                power += cfg.power_burst_amp_w * env_power * wander
            power = max(0.0, power)

            # ---- Memory bandwidth ---------------------------------------- #
            mem = (cfg.mem_base
                   + cfg.mem_slow_amp * math.sin(TWO_PI * t / cfg.mem_slow_period_s + 1.3)
                   + gauss(0.0, cfg.mem_noise_sigma))
            if anomalous:
                mem += cfg.mem_burst_amp * env_mem * wander
            mem = _clamp01(mem)

            # ---- Per-core CPU load --------------------------------------- #
            cores: List[float] = []
            for i in range(n):
                load = (layout["base"][i]
                        + cfg.cpu_slow_amp * math.sin(
                            TWO_PI * t / cfg.cpu_slow_period_s + layout["phase"][i])
                        + gauss(0.0, cfg.cpu_noise_sigma))
                if anomalous:
                    # Same envelope as power -> the correlation a detector can exploit.
                    load += layout["burst_gain"][i] * env_power * wander
                cores.append(round(_clamp01(load), 5))

        return {
            "timestamp": float(timestamp),
            "t_offset_s": round(t, 6),
            "profile": profile,
            "cpu_cycle_distribution": cores,
            "power_draw_watts": round(power, 4),
            "memory_bandwidth_utilization": round(mem, 5),
        }

    def timeline(self, profile: str, duration_s: float, rate_hz: float,
                 num_cores: Optional[int] = None, start_epoch: Optional[float] = None,
                 anomaly_after_s: float = 0.0) -> List[Dict[str, Any]]:
        """
        Build an evenly spaced series. If profile == "anomaly" and
        anomaly_after_s > 0, samples before that offset are labelled "normal",
        which yields a ground-truth-labelled onset for detector evaluation.
        """
        if duration_s <= 0 or rate_hz <= 0:
            raise ValueError("duration and rate must be positive")
        count = int(round(duration_s * rate_hz))
        if count < 1:
            raise ValueError("duration * rate yields zero samples")
        if count > MAX_TIMELINE_SAMPLES:
            raise ValueError("refusing to generate more than %d samples" % MAX_TIMELINE_SAMPLES)
        epoch = self._epoch0 if start_epoch is None else start_epoch
        out: List[Dict[str, Any]] = []
        for i in range(count):
            t = i / rate_hz
            label = "anomaly" if (profile == "anomaly" and t >= anomaly_after_s) else "normal"
            out.append(self.sample(label, t_offset=t, timestamp=epoch + t, num_cores=num_cores))
        return out


# --------------------------------------------------------------------------- #
# HTTP server
# --------------------------------------------------------------------------- #
class MetricsHandler(BaseHTTPRequestHandler):
    server_version = "AnchorGuardSim/" + __version__

    def _send_json(self, status: int, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802 (http.server naming)
        gen: TelemetryGenerator = self.server.generator  # type: ignore[attr-defined]
        url = urlparse(self.path)
        query = parse_qs(url.query)

        if url.path == "/health":
            self._send_json(200, {"status": "ok", "version": __version__,
                                  "uptime_s": round(gen.uptime_s, 3), "seed": gen.seed})
            return

        if url.path == "/metrics":
            profile = query.get("profile", ["normal"])[0].strip().lower()
            if profile not in PROFILES:
                self._send_json(400, {"error": "profile must be one of %s" % (list(PROFILES),)})
                return
            raw_cores = query.get("cores", [str(gen.default_cores)])[0]
            try:
                cores = int(raw_cores)
                if not 1 <= cores <= MAX_CORES:
                    raise ValueError
            except ValueError:
                self._send_json(400, {"error": "cores must be an integer in 1..%d" % MAX_CORES})
                return
            self._send_json(200, gen.sample(profile, num_cores=cores))
            return

        self._send_json(404, {"error": "not found", "routes": ["/metrics", "/health"]})

    def log_message(self, fmt: str, *args: Any) -> None:
        LOG.info("%s - %s", self.address_string(), fmt % args)


def run_server(host: str, port: int, generator: TelemetryGenerator) -> int:
    try:
        httpd = ThreadingHTTPServer((host, port), MetricsHandler)
    except OSError as exc:
        LOG.error("Cannot bind %s:%d - %s", host, port, exc)
        return 1
    httpd.daemon_threads = True
    httpd.generator = generator  # type: ignore[attr-defined]
    LOG.info("Serving on http://%s:%d  (seed=%d, cores=%d)  Ctrl+C to stop",
             host, port, generator.seed, generator.default_cores)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        LOG.info("Shutting down")
    finally:
        httpd.server_close()
    return 0


# --------------------------------------------------------------------------- #
# Timeline writer
# --------------------------------------------------------------------------- #
def write_json_atomic(path: str, document: Dict[str, Any], pretty: bool) -> None:
    """Write to a temp file in the target directory, then rename into place."""
    directory = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(prefix=".telemetry_", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            if pretty:
                json.dump(document, fh, indent=2)
            else:
                json.dump(document, fh, separators=(",", ":"))
            fh.write("\n")
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def run_generate(args: argparse.Namespace, generator: TelemetryGenerator) -> int:
    cfg = generator.config
    if args.rate < 2.0 * cfg.burst_freq_hz and args.profile == "anomaly":
        LOG.warning("rate %.1f Hz is below the Nyquist rate (%.1f Hz) for the %.1f Hz burst; "
                    "the burst will alias.", args.rate, 2.0 * cfg.burst_freq_hz, cfg.burst_freq_hz)
    start_epoch = args.start_epoch if args.start_epoch is not None else time.time()
    try:
        samples = generator.timeline(args.profile, args.duration, args.rate,
                                     num_cores=args.cores, start_epoch=start_epoch,
                                     anomaly_after_s=args.anomaly_after)
    except ValueError as exc:
        LOG.error("%s", exc)
        return 2

    document = {
        "metadata": {
            "generator": "AnchorGuard telemetry_simulator " + __version__,
            "profile": args.profile,
            "anomaly_after_s": args.anomaly_after if args.profile == "anomaly" else None,
            "seed": generator.seed,
            "cores": args.cores,
            "duration_s": args.duration,
            "rate_hz": args.rate,
            "sample_count": len(samples),
            "start_epoch": start_epoch,
            "config": asdict(cfg),
        },
        "samples": samples,
    }
    try:
        write_json_atomic(args.output, document, args.pretty)
    except OSError as exc:
        LOG.error("Could not write %s: %s", args.output, exc)
        return 1
    LOG.info("Wrote %d samples to %s (seed=%d)", len(samples), args.output, generator.seed)
    return 0


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="telemetry_simulator.py",
        description="AnchorGuard synthetic hardware telemetry (normal vs. anomalous builds).")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)

    def positive_float(text: str) -> float:
        value = float(text)
        if value <= 0:
            raise argparse.ArgumentTypeError("must be > 0")
        return value

    def core_count(text: str) -> int:
        value = int(text)
        if not 1 <= value <= MAX_CORES:
            raise argparse.ArgumentTypeError("must be in 1..%d" % MAX_CORES)
        return value

    serve = sub.add_parser("serve", help="run the HTTP /metrics and /health server")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    serve.add_argument("--cores", type=core_count, default=DEFAULT_CORES,
                       help="default core count when ?cores= is omitted")
    serve.add_argument("--seed", type=int, default=None, help="RNG seed (random if omitted)")

    gen = sub.add_parser("generate", help="write a synthetic timeline to a JSON file")
    gen.add_argument("--profile", choices=PROFILES, default="normal")
    gen.add_argument("--duration", type=positive_float, default=60.0, help="seconds")
    gen.add_argument("--rate", type=positive_float, default=50.0, help="samples per second (Hz)")
    gen.add_argument("--cores", type=core_count, default=DEFAULT_CORES)
    gen.add_argument("--seed", type=int, default=None, help="RNG seed (random if omitted)")
    gen.add_argument("--anomaly-after", type=float, default=0.0, metavar="SECONDS",
                     help="with --profile anomaly: stay 'normal' until this offset")
    gen.add_argument("--start-epoch", type=float, default=None,
                     help="fixed epoch for the first sample (for byte-identical reruns)")
    gen.add_argument("--output", "-o", default="telemetry_timeline.json")
    gen.add_argument("--pretty", action="store_true", help="indent the JSON output")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        stream=sys.stderr)
    args = build_parser().parse_args(argv)
    generator = TelemetryGenerator(seed=args.seed, num_cores=args.cores)
    if args.command == "serve":
        return run_server(args.host, args.port, generator)
    return run_generate(args, generator)


if __name__ == "__main__":
    sys.exit(main())
